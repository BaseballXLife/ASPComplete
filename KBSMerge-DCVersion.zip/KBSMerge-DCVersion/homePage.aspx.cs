﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class KSB_Website_Files_homePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void loginButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("registration.aspx");

    }

    protected void AdvisorLogin(object sender, EventArgs e)
    {
        Response.Redirect("https://cas.iu.edu/cas/login?cassvc=IU&casurl=http://asp-net.cs.iupui.edu/spring17/maniodel/courseProject/KBSMerge/AdvisorPortal.aspx");

    }

    protected void GuestLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("registration.aspx");
    }

}